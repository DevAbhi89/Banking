package com.abm.repository;

public interface TransactionRepo {

}
