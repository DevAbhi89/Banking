package com.abm.repository;

public interface UserRepo {

}
